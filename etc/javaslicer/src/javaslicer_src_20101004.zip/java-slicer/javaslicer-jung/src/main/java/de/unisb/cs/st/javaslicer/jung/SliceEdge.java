/** License information:
 *    Component: javaslicer-jung
 *    Package:   de.unisb.cs.st.javaslicer.jung
 *    Class:     SliceEdge
 *    Filename:  javaslicer-jung/src/main/java/de/unisb/cs/st/javaslicer/jung/SliceEdge.java
 *
 * This file is part of the JavaSlicer tool, developed by Clemens Hammacher at Saarland University.
 * See http://www.st.cs.uni-saarland.de/javaslicer/ for more information.
 *
 * This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send a
 * letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
 */
package de.unisb.cs.st.javaslicer.jung;

import de.unisb.cs.st.javaslicer.variables.Variable;


public class SliceEdge<VertexType> {

	private final VertexType start;
	private final VertexType end;
	private final Variable variable;

	public SliceEdge(VertexType start, VertexType end,
			Variable variable) {
		if (start == null || end == null)
			throw new NullPointerException("start node and end node must not be null");
		this.start = start;
		this.end = end;
		this.variable = variable;
	}

	public VertexType getStart() {
		return this.start;
	}

	public VertexType getEnd() {
		return this.end;
	}

	public Variable getVariable() {
		return this.variable;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.end.hashCode();
		result = prime * result + this.start.hashCode();
		result = prime * result + (this.variable == null ? 0 : this.variable.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SliceEdge<?> other = (SliceEdge<?>) obj;
		if (!this.end.equals(other.end))
			return false;
		if (!this.start.equals(other.start))
			return false;
		if (this.variable == null) {
			if (other.variable != null)
				return false;
		} else if (!this.variable.equals(other.variable))
			return false;
		return true;
	}


}
